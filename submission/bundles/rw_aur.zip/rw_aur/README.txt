HIPPARCHUS reproduction bundle: RW Aurigae: a real brightness change

Built 2026-11-16T09:59:52+00:00 from the published evidence (nothing recomputed).
No FITS data inside: every input is a link with its sha256 in manifest.json.

Check the bundle against your cache, or (slow, opt-in) against the archive:
    python tools/bundle.py verify .            # cache only
    python tools/bundle.py verify . --network  # re-download and compare checksums

Rerun the analysis from the repository:
    cd backend
    python -m venv .venv && .venv/bin/pip install -r ../environment/requirements-freeze.txt
    .venv/bin/pip install -e .
    .venv/bin/python scripts/reproduce_evidence.py      # rewrites submission/evidence/<target>.json
    .venv/bin/python scripts/reproduce_validation.py    # null tests + SIMULATED injections
    .venv/bin/python scripts/reproduce_robustness.py    # aperture/annulus/mask grid
    .venv/bin/python -m hipparchus.bundle verify ../submission/bundles/rw_aur.zip

Files:
  evidence/       evidence JSON of this case (and slices of the shared files)
  environment/    pyproject.toml, pip freeze, python version
  figures/        figures drawn from the evidence
  report.html     mini scientific report
  manifest.json   DOIs, URLs, checksums, parameters, source-file checksums, commands
