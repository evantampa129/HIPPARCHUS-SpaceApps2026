HIPPARCHUS reproduction bundle: WISE 0855-0714: no change at the limit of the data

Built 2026-11-16T10:00:12+00:00 from the published evidence (nothing recomputed).
No FITS data inside: every input is a link with its sha256 in manifest.json.

Check the bundle against your cache, or (slow, opt-in) against the archive:
    python tools/bundle.py verify .            # cache only
    python tools/bundle.py verify . --network  # re-download and compare checksums

Rerun the analysis from the repository:
    cd backend
    python -m venv .venv && .venv/bin/pip install -r ../environment/requirements-freeze.txt
    .venv/bin/pip install -e .
    .venv/bin/python scripts/reproduce_evidence.py
    .venv/bin/python scripts/reproduce_validation.py
    .venv/bin/python -m hipparchus.bundle verify ../submission/bundles/wise0855.zip

Files:
  evidence/       evidence JSON of this case (and slices of the shared files)
  environment/    pyproject.toml, pip freeze, python version
  figures/        figures drawn from the evidence
  report.html     mini scientific report
  manifest.json   DOIs, URLs, checksums, parameters, source-file checksums, commands
